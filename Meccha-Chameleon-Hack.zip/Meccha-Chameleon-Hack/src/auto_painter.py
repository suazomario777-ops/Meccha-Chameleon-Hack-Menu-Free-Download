Auto Painter Hack Example
# Auto Painter
