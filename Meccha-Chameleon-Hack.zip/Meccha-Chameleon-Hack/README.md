# Meccha Chameleon Hack

Репозиторий с инструментами и читами для игры **Meccha Chameleon** (Mecha Chameleon).

## Особенности
- Авто-пейнт (проекция изображений на модель)
- Камуфляж (Chameleon Camo)
- Другие хаки (aimbot, wallhack, freecam и т.д. — в разработке)

## Структура
```
Meccha-Chameleon-Hack/
├── README.md
├── src/
│   └── auto_painter.py     # Пример авто-пейнтера
├── tools/
├── docs/
└── .git/
```

## Как использовать
1. Клонируй репозиторий
2. Запусти нужный скрипт
3. Играй с преимуществом 😏

**Предупреждение**: Используй на свой страх и риск (античиты могут баннуть).

## Contributing
Pull requests welcome!

